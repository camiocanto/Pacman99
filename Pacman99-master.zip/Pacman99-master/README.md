# 99sitioweb
Un sitio web para una tarea de Aplicaciones Móviles. Basado en un juego que creé en desarrollo.
Erik Bianco - Ezequiel Palladino - Tomás Yaciura
# [Miralo sin descargar nada!](http://erikbianco.me/pacman99)
Nota: Mirandoló localmente, todos los links llevan a indexes. En la version online, estos links funcionan adecuadamente.
